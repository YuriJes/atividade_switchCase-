<?php
$favcolor = $_POST ["favcolor"]

switch($favcolor){
    case 'Vermelho':
        echo "<p> Sua cor favorita é vermelho!</p>";
        break;
    case 'Azul':
         echo "<p> Sua cor favorita é azul!</p>";
         break;
         case 'Verde':
            echo "<p> Sua cor favorita é verde!</p>";
            break;
            default
            echo "<p> Sua cor não é favorita é nenhuma dessas!</p>"
    }
    ?>
